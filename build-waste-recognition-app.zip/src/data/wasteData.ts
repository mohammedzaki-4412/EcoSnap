export interface WasteInfo {
  label: string;
  emoji: string;
  bin: string;
  binColor: string;
  tip: string;
  impact: string;
  theme: {
    primary: string;
    secondary: string;
    bg: string;
    gradient: string;
    glow: string;
    textAccent: string;
  };
  facts: string[];
}

export const wasteDatabase: Record<string, WasteInfo> = {
  "Green (biodegradable/wet waste)": {
    label: "Organic / Wet Waste",
    emoji: "🍃",
    bin: "Green Bin",
    binColor: "#22c55e",
    tip: "Compost this at home or drop at a wet waste collection point to create natural fertilizer.",
    impact: "Biodegrades in 2–4 weeks when composted — the most eco-friendly option!",
    theme: {
      primary: "#16a34a",
      secondary: "#22c55e",
      bg: "rgba(34,197,94,0.08)",
      gradient: "linear-gradient(135deg, #14532d, #16a34a, #4ade80)",
      glow: "rgba(34,197,94,0.4)",
      textAccent: "#4ade80",
    },
    facts: [
      "Composting reduces landfill waste by up to 30%",
      "1kg of compost enriches 10L of soil",
      "Wet waste forms 60% of household garbage",
    ],
  },
  "Blue (dry/recyclable waste)": {
    label: "Dry / Recyclable Waste",
    emoji: "♻️",
    bin: "Blue Bin",
    binColor: "#3b82f6",
    tip: "Clean and dry before recycling. Drop at nearest recycling center or dry waste collection point.",
    impact: "Recycling saves 60–80% of energy versus making new products from scratch.",
    theme: {
      primary: "#1d4ed8",
      secondary: "#3b82f6",
      bg: "rgba(59,130,246,0.08)",
      gradient: "linear-gradient(135deg, #1e3a8a, #1d4ed8, #60a5fa)",
      glow: "rgba(59,130,246,0.4)",
      textAccent: "#60a5fa",
    },
    facts: [
      "Recycling one plastic bottle saves enough energy to power a bulb for 3 hours",
      "Paper can be recycled up to 7 times",
      "Aluminium can be recycled indefinitely",
    ],
  },
  "Red (hazardous/biomedical waste)": {
    label: "Hazardous / Biomedical",
    emoji: "⚠️",
    bin: "Red Bin",
    binColor: "#ef4444",
    tip: "Do NOT mix with regular waste. Take to a certified hazardous waste disposal facility or pharmacy drop-off.",
    impact: "Improper disposal contaminates soil and water, posing serious health and environmental risks.",
    theme: {
      primary: "#b91c1c",
      secondary: "#ef4444",
      bg: "rgba(239,68,68,0.08)",
      gradient: "linear-gradient(135deg, #7f1d1d, #b91c1c, #f87171)",
      glow: "rgba(239,68,68,0.4)",
      textAccent: "#f87171",
    },
    facts: [
      "Medical waste must be incinerated at 1000°C+",
      "Hazardous chemicals can persist in soil for decades",
      "Only certified facilities can safely process biomedical waste",
    ],
  },
};

export const getBadge = (points: number): { icon: string; label: string; next: number | null } => {
  if (points >= 200) return { icon: "🌍", label: "Earth Hero", next: null };
  if (points >= 80)  return { icon: "🌿", label: "Eco Saver", next: 200 };
  return { icon: "🌱", label: "Beginner", next: 80 };
};
