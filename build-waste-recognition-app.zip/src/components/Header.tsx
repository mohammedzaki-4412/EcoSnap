interface BadgeInfo {
  icon: string;
  label: string;
  next: number | null;
}

interface Props {
  userName: string;
  points: number;
  pointsAnim: boolean;
  badge: BadgeInfo;
  scanCount: number;
  onHistoryToggle: () => void;
  showHistory: boolean;
  onLogout?: () => void;
}

export default function Header({ userName, points, pointsAnim, badge, scanCount, onHistoryToggle, showHistory, onLogout }: Props) {
  return (
    <header style={{
      background: "linear-gradient(135deg, #0f4c35 0%, #1a7a55 100%)",
      padding: "0 24px",
      boxShadow: "0 4px 32px rgba(15,76,53,0.4)",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      <div style={{
        maxWidth: 880,
        margin: "0 auto",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: 68,
      }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 42, height: 42,
            borderRadius: 14,
            background: "linear-gradient(135deg, #2ecc71, #1a9e55)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 4px 14px rgba(46,204,113,0.4)",
            fontSize: 22,
          }}>♻️</div>
          <div>
            <h1 style={{ margin: 0, color: "#fff", fontSize: 20, fontWeight: 800, letterSpacing: "-0.5px" }}>EcoSnap</h1>
            <p style={{ margin: 0, color: "rgba(255,255,255,0.6)", fontSize: 11, fontWeight: 500 }}>AI Waste Classifier</p>
          </div>
        </div>

        {/* Center — Welcome */}
        <div style={{ color: "rgba(255,255,255,0.85)", fontSize: 14, fontWeight: 500, textAlign: "center" }}>
          <span style={{ display: "block" }}>Welcome, <span style={{ fontWeight: 700, color: "#4ade80" }}>{userName}</span> 👋</span>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{scanCount} scan{scanCount !== 1 ? "s" : ""} completed</span>
        </div>

        {/* Right — Points + History */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {/* Points */}
          <div style={{
            background: "rgba(255,255,255,0.12)",
            border: "1px solid rgba(255,255,255,0.2)",
            borderRadius: 14,
            padding: "8px 16px",
            display: "flex",
            alignItems: "center",
            gap: 8,
            transition: "transform 0.3s",
            transform: pointsAnim ? "scale(1.15)" : "scale(1)",
          }}>
            <span style={{ fontSize: 18 }}>{badge.icon}</span>
            <div>
              <p style={{
                margin: 0,
                color: pointsAnim ? "#4ade80" : "#fff",
                fontWeight: 800,
                fontSize: 17,
                transition: "color 0.3s",
                lineHeight: 1,
              }}>{points}</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.5)", fontSize: 10 }}>POINTS</p>
            </div>
          </div>

          {/* History button */}
          <button
            onClick={onHistoryToggle}
            style={{
              background: showHistory ? "rgba(74,222,128,0.2)" : "rgba(255,255,255,0.1)",
              border: `1px solid ${showHistory ? "rgba(74,222,128,0.5)" : "rgba(255,255,255,0.2)"}`,
              borderRadius: 14,
              padding: "8px 14px",
              color: "#fff",
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 600,
              fontFamily: "'Inter', sans-serif",
              transition: "all 0.2s",
            }}
          >
            📋 History
          </button>

          {/* Logout */}
          {onLogout && (
            <button
              onClick={onLogout}
              title="Switch user"
              style={{
                background: "rgba(255,255,255,0.08)",
                border: "1px solid rgba(255,255,255,0.15)",
                borderRadius: 14,
                padding: "8px 12px",
                color: "rgba(255,255,255,0.6)",
                cursor: "pointer",
                fontSize: 13,
                fontWeight: 600,
                fontFamily: "'Inter', sans-serif",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => { (e.currentTarget).style.background = "rgba(255,255,255,0.15)"; (e.currentTarget).style.color = "#fff"; }}
              onMouseLeave={(e) => { (e.currentTarget).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget).style.color = "rgba(255,255,255,0.6)"; }}
            >
              ↩ Switch
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
