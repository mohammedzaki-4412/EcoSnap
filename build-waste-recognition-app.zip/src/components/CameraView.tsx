import { RefObject } from "react";

interface Theme {
  primary: string;
  secondary: string;
  bg: string;
  gradient: string;
  glow: string;
  textAccent: string;
}

interface Props {
  videoRef: RefObject<HTMLVideoElement | null>;
  cameraActive: boolean;
  scanning: boolean;
  modelLoading: boolean;
  modelLoaded: boolean;
  onStart: () => void;
  onStop: () => void;
  onScan: () => void;
  resultTheme?: Theme;
}

export default function CameraView({
  videoRef,
  cameraActive,
  scanning,
  modelLoading,
  modelLoaded,
  onStart,
  onStop,
  onScan,
  resultTheme,
}: Props) {
  const accentColor = resultTheme?.secondary || "#2ecc71";
  const glowColor = resultTheme?.glow || "rgba(46,204,113,0.4)";

  return (
    <div style={{
      background: "rgba(255,255,255,0.85)",
      backdropFilter: "blur(20px)",
      borderRadius: 28,
      overflow: "hidden",
      boxShadow: "0 8px 40px rgba(0,0,0,0.1), 0 0 0 1px rgba(255,255,255,0.8)",
      border: "1px solid rgba(255,255,255,0.8)",
    }}>
      {/* Camera area */}
      <div style={{
        position: "relative",
        background: "#0a0a0a",
        aspectRatio: "4/3",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}>
        {/* Video element */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: cameraActive ? "block" : "none",
          }}
        />

        {/* Idle state */}
        {!cameraActive && (
          <div style={{ textAlign: "center", color: "#fff", padding: 32 }}>
            <div style={{
              fontSize: 72,
              marginBottom: 16,
              animation: "breathe 2.5s infinite ease-in-out",
              display: "inline-block",
            }}>📷</div>
            <h3 style={{ margin: "0 0 8px", fontWeight: 700, fontSize: 20 }}>Camera Ready</h3>
            <p style={{ margin: 0, color: "rgba(255,255,255,0.6)", fontSize: 14 }}>
              Tap "Open Camera" to begin scanning
            </p>
          </div>
        )}

        {/* Scan overlay — corners */}
        {cameraActive && (
          <>
            {/* Scan frame corners */}
            {[
              { top: 24, left: 24, borderTop: `3px solid ${accentColor}`, borderLeft: `3px solid ${accentColor}`, borderRadius: "12px 0 0 0" },
              { top: 24, right: 24, borderTop: `3px solid ${accentColor}`, borderRight: `3px solid ${accentColor}`, borderRadius: "0 12px 0 0" },
              { bottom: 24, left: 24, borderBottom: `3px solid ${accentColor}`, borderLeft: `3px solid ${accentColor}`, borderRadius: "0 0 0 12px" },
              { bottom: 24, right: 24, borderBottom: `3px solid ${accentColor}`, borderRight: `3px solid ${accentColor}`, borderRadius: "0 0 12px 0" },
            ].map((style, i) => (
              <div key={i} style={{
                position: "absolute",
                width: 40, height: 40,
                ...style,
                transition: "border-color 0.4s",
              }} />
            ))}

            {/* Scan line animation */}
            {scanning && (
              <div style={{
                position: "absolute",
                left: "12%", right: "12%",
                height: 3,
                background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)`,
                boxShadow: `0 0 12px ${glowColor}`,
                animation: "scanLine 1.2s infinite ease-in-out",
                borderRadius: 99,
              }} />
            )}

            {/* Status badge */}
            <div style={{
              position: "absolute",
              top: 14,
              left: "50%",
              transform: "translateX(-50%)",
              background: scanning
                ? "rgba(239,68,68,0.9)"
                : modelLoading
                  ? "rgba(245,158,11,0.9)"
                  : "rgba(22,163,74,0.9)",
              backdropFilter: "blur(8px)",
              borderRadius: 99,
              padding: "5px 14px",
              color: "#fff",
              fontSize: 12,
              fontWeight: 700,
              display: "flex",
              alignItems: "center",
              gap: 6,
              letterSpacing: "0.3px",
            }}>
              <span style={{
                width: 7, height: 7,
                borderRadius: "50%",
                background: "#fff",
                display: "inline-block",
                animation: scanning || modelLoading ? "blink 0.8s infinite" : "none",
                opacity: 0.9,
              }} />
              {scanning ? "ANALYZING..." : modelLoading ? "LOADING AI..." : "LIVE"}
            </div>

            {/* Scanning overlay dim */}
            {scanning && (
              <div style={{
                position: "absolute",
                inset: 0,
                background: "rgba(0,0,0,0.35)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}>
                <div style={{ textAlign: "center", color: "#fff" }}>
                  <div style={{
                    width: 56, height: 56,
                    border: "3px solid rgba(255,255,255,0.2)",
                    borderTop: `3px solid ${accentColor}`,
                    borderRadius: "50%",
                    animation: "spin 0.9s linear infinite",
                    margin: "0 auto 14px",
                  }} />
                  <p style={{ margin: 0, fontWeight: 700, fontSize: 16 }}>Classifying...</p>
                  <p style={{ margin: "4px 0 0", color: "rgba(255,255,255,0.6)", fontSize: 12 }}>AI model processing frame</p>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Controls */}
      <div style={{ padding: "20px 24px", display: "flex", gap: 12, flexWrap: "wrap" }}>
        {!cameraActive ? (
          <button
            onClick={onStart}
            style={{
              flex: 1,
              padding: "15px",
              borderRadius: 16,
              border: "none",
              background: "linear-gradient(135deg, #0f4c35, #1a7a55, #2ecc71)",
              color: "#fff",
              fontSize: 15,
              fontWeight: 700,
              cursor: "pointer",
              boxShadow: "0 6px 24px rgba(46,204,113,0.4)",
              transition: "transform 0.15s, box-shadow 0.15s",
              fontFamily: "'Inter', sans-serif",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            }}
            onMouseEnter={(e) => { (e.currentTarget).style.transform = "translateY(-2px)"; (e.currentTarget).style.boxShadow = "0 10px 32px rgba(46,204,113,0.55)"; }}
            onMouseLeave={(e) => { (e.currentTarget).style.transform = "translateY(0)"; (e.currentTarget).style.boxShadow = "0 6px 24px rgba(46,204,113,0.4)"; }}
          >
            📷 Open Camera
          </button>
        ) : (
          <>
            <button
              onClick={onScan}
              disabled={scanning || modelLoading || !modelLoaded}
              style={{
                flex: 2,
                padding: "15px",
                borderRadius: 16,
                border: "none",
                background: scanning || modelLoading || !modelLoaded
                  ? "#e5e7eb"
                  : `linear-gradient(135deg, ${resultTheme?.primary || "#0f4c35"}, ${resultTheme?.secondary || "#2ecc71"})`,
                color: scanning || modelLoading || !modelLoaded ? "#9ca3af" : "#fff",
                fontSize: 15,
                fontWeight: 700,
                cursor: scanning || modelLoading || !modelLoaded ? "not-allowed" : "pointer",
                boxShadow: scanning || modelLoading || !modelLoaded ? "none" : `0 6px 24px ${glowColor}`,
                transition: "all 0.2s",
                fontFamily: "'Inter', sans-serif",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
              }}
              onMouseEnter={(e) => {
                if (!scanning && !modelLoading && modelLoaded) {
                  (e.currentTarget).style.transform = "translateY(-2px)";
                  (e.currentTarget).style.boxShadow = `0 10px 32px ${glowColor}`;
                }
              }}
              onMouseLeave={(e) => {
                (e.currentTarget).style.transform = "translateY(0)";
                (e.currentTarget).style.boxShadow = scanning || modelLoading || !modelLoaded ? "none" : `0 6px 24px ${glowColor}`;
              }}
            >
              {scanning ? "⏳ Scanning..." : modelLoading ? "⚙️ Loading AI Model..." : "🔍 Scan Waste"}
            </button>
            <button
              onClick={onStop}
              style={{
                flex: 1,
                padding: "15px",
                borderRadius: 16,
                border: "1.5px solid #e5e7eb",
                background: "#fff",
                color: "#374151",
                fontSize: 15,
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.2s",
                fontFamily: "'Inter', sans-serif",
              }}
              onMouseEnter={(e) => { (e.currentTarget).style.background = "#f9fafb"; }}
              onMouseLeave={(e) => { (e.currentTarget).style.background = "#fff"; }}
            >
              ✕ Stop
            </button>
          </>
        )}
      </div>

      <style>{`
        @keyframes scanLine {
          0% { top: 15%; }
          50% { top: 82%; }
          100% { top: 15%; }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.2; }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.08); }
        }
      `}</style>
    </div>
  );
}
