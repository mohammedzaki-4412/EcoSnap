import { useState, useEffect } from "react";
import { ScanResult } from "./MainApp";

interface Props {
  result: ScanResult;
  onRescan: () => void;
}

export default function ResultCard({ result, onRescan }: Props) {
  const [mounted, setMounted] = useState(false);
  const [barWidth, setBarWidth] = useState(0);
  const [currentFact, setCurrentFact] = useState(0);
  const { wasteInfo, confidence } = result;
  const { theme, facts } = wasteInfo;

  useEffect(() => {
    setMounted(false);
    setBarWidth(0);
    const t1 = setTimeout(() => setMounted(true), 50);
    const t2 = setTimeout(() => setBarWidth(confidence), 200);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [result]);

  useEffect(() => {
    if (!facts.length) return;
    const interval = setInterval(() => {
      setCurrentFact((c) => (c + 1) % facts.length);
    }, 3500);
    return () => clearInterval(interval);
  }, [facts]);

  const confidenceColor =
    confidence >= 75 ? "#22c55e" : confidence >= 50 ? "#f59e0b" : "#ef4444";

  return (
    <div style={{
      opacity: mounted ? 1 : 0,
      transform: mounted ? "translateX(0) scale(1)" : "translateX(30px) scale(0.96)",
      transition: "opacity 0.5s ease, transform 0.5s cubic-bezier(0.34,1.56,0.64,1)",
    }}>
      {/* Main Result Card */}
      <div style={{
        background: "rgba(255,255,255,0.92)",
        backdropFilter: "blur(24px)",
        borderRadius: 28,
        overflow: "hidden",
        boxShadow: `0 8px 48px rgba(0,0,0,0.1), 0 0 0 1px ${theme.glow}`,
        border: `1.5px solid ${theme.secondary}30`,
      }}>
        {/* Gradient top banner */}
        <div style={{
          background: theme.gradient,
          padding: "28px 28px 24px",
          position: "relative",
          overflow: "hidden",
        }}>
          <div style={{
            position: "absolute", width: 200, height: 200,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.08)",
            top: -60, right: -60,
          }} />
          <div style={{
            position: "absolute", width: 120, height: 120,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.06)",
            bottom: -40, left: 20,
          }} />

          <div style={{ display: "flex", alignItems: "center", gap: 16, position: "relative" }}>
            <div style={{
              width: 72, height: 72,
              borderRadius: 22,
              background: "rgba(255,255,255,0.2)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 38,
              backdropFilter: "blur(8px)",
              border: "1.5px solid rgba(255,255,255,0.3)",
              flexShrink: 0,
              animation: "resultPop 0.6s cubic-bezier(0.34,1.56,0.64,1)",
            }}>
              {wasteInfo.emoji}
            </div>
            <div>
              <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.75)", fontSize: 11, fontWeight: 700, letterSpacing: "1.5px", textTransform: "uppercase" }}>
                Detected
              </p>
              <h2 style={{ margin: "0 0 4px", color: "#fff", fontSize: 21, fontWeight: 800, lineHeight: 1.15 }}>
                {wasteInfo.label}
              </h2>
              <div style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                background: "rgba(255,255,255,0.18)",
                border: "1px solid rgba(255,255,255,0.3)",
                borderRadius: 99,
                padding: "3px 10px",
              }}>
                <span style={{
                  width: 6, height: 6,
                  borderRadius: "50%",
                  background: wasteInfo.binColor,
                  display: "inline-block",
                }} />
                <span style={{ color: "#fff", fontSize: 12, fontWeight: 600 }}>{wasteInfo.bin}</span>
              </div>
            </div>
          </div>
        </div>

        <div style={{ padding: "24px 28px" }}>
          {/* Confidence */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: "#374151" }}>AI Confidence</span>
              <span style={{ fontSize: 15, fontWeight: 800, color: confidenceColor }}>{confidence}%</span>
            </div>
            <div style={{ background: "#f3f4f6", borderRadius: 99, height: 10, overflow: "hidden" }}>
              <div style={{
                height: "100%",
                width: `${barWidth}%`,
                background: confidence >= 75
                  ? `linear-gradient(90deg, ${theme.primary}, ${theme.secondary})`
                  : confidence >= 50
                    ? "linear-gradient(90deg, #d97706, #f59e0b)"
                    : "linear-gradient(90deg, #b91c1c, #ef4444)",
                borderRadius: 99,
                transition: "width 1s cubic-bezier(0.34,1.56,0.64,1)",
                boxShadow: `0 0 10px ${confidenceColor}55`,
              }} />
            </div>
            <p style={{ margin: "8px 0 0", fontSize: 11, color: "#9ca3af", fontWeight: 500 }}>
              {confidence >= 80 ? "✅ High confidence detection" : confidence >= 55 ? "⚡ Moderate confidence — try better lighting" : "⚠️ Low confidence — reposition item"}
            </p>
          </div>

          {/* Tip & Impact */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <InfoBlock icon="♻️" title="How to Dispose" color={theme.primary} bg={theme.bg}>
              {wasteInfo.tip}
            </InfoBlock>
            <InfoBlock icon="🌍" title="Environmental Impact" color={theme.primary} bg={theme.bg}>
              {wasteInfo.impact}
            </InfoBlock>
          </div>

          {/* Rotating fact */}
          {facts.length > 0 && (
            <div style={{
              marginTop: 18,
              background: `${theme.primary}0f`,
              border: `1px solid ${theme.secondary}30`,
              borderRadius: 16,
              padding: "14px 16px",
              transition: "all 0.4s",
            }}>
              <p style={{ margin: "0 0 4px", fontSize: 11, fontWeight: 700, color: theme.primary, letterSpacing: "1px", textTransform: "uppercase" }}>
                💡 Eco Fact
              </p>
              <p key={currentFact} style={{
                margin: 0,
                fontSize: 13,
                color: "#374151",
                lineHeight: 1.5,
                fontWeight: 500,
                animation: "fadeIn 0.5s ease",
              }}>
                {facts[currentFact]}
              </p>
            </div>
          )}

          {/* Points earned badge */}
          <div style={{
            marginTop: 18,
            background: "linear-gradient(135deg, #f0fdf4, #dcfce7)",
            border: "1px solid #bbf7d0",
            borderRadius: 16,
            padding: "14px 18px",
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}>
            <span style={{ fontSize: 28 }}>🎉</span>
            <div>
              <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#15803d" }}>+10 Points Earned!</p>
              <p style={{ margin: 0, fontSize: 12, color: "#4ade80" }}>Keep scanning to level up your badge</p>
            </div>
          </div>

          {/* Rescan button */}
          <button
            onClick={onRescan}
            style={{
              width: "100%",
              marginTop: 18,
              padding: "14px",
              borderRadius: 16,
              border: `1.5px solid ${theme.secondary}50`,
              background: "transparent",
              color: theme.primary,
              fontSize: 14,
              fontWeight: 700,
              cursor: "pointer",
              transition: "all 0.2s",
              fontFamily: "'Inter', sans-serif",
            }}
            onMouseEnter={(e) => { (e.currentTarget).style.background = theme.bg; }}
            onMouseLeave={(e) => { (e.currentTarget).style.background = "transparent"; }}
          >
            🔄 Scan Another Item
          </button>
        </div>
      </div>

      <style>{`
        @keyframes resultPop {
          0% { transform: scale(0.4) rotate(-10deg); opacity: 0; }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function InfoBlock({ icon, title, color, bg, children }: { icon: string; title: string; color: string; bg: string; children: string }) {
  return (
    <div style={{
      background: bg,
      borderRadius: 16,
      padding: "14px 16px",
      display: "flex",
      gap: 12,
      alignItems: "flex-start",
    }}>
      <span style={{ fontSize: 20, flexShrink: 0, marginTop: 1 }}>{icon}</span>
      <div>
        <p style={{ margin: "0 0 4px", fontSize: 11, fontWeight: 700, color, letterSpacing: "0.8px", textTransform: "uppercase" }}>{title}</p>
        <p style={{ margin: 0, fontSize: 13, color: "#374151", lineHeight: 1.55, fontWeight: 500 }}>{children}</p>
      </div>
    </div>
  );
}
