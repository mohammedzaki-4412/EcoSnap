import { useState, useEffect } from "react";

interface Props {
  onGetStarted: (name: string) => void;
  isTransitioning: boolean;
}

export default function OnboardingScreen({ onGetStarted, isTransitioning }: Props) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [mounted, setMounted] = useState(false);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; delay: number; duration: number }>>([]);

  useEffect(() => {
    setMounted(true);
    const p = Array.from({ length: 18 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 8 + 4,
      delay: Math.random() * 5,
      duration: Math.random() * 6 + 6,
    }));
    setParticles(p);
  }, []);

  const handleSubmit = () => {
    if (!name.trim()) {
      setError("Please enter your name to continue");
      return;
    }
    setError("");
    onGetStarted(name.trim());
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f4c35 0%, #1a7a55 25%, #2ecc71 60%, #a8edbc 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "'Inter', sans-serif",
        position: "relative",
        overflow: "hidden",
        opacity: isTransitioning ? 0 : 1,
        transform: isTransitioning ? "scale(1.04)" : "scale(1)",
        transition: "opacity 0.6s ease, transform 0.6s ease",
      }}
    >
      {/* Floating particles */}
      {particles.map((p) => (
        <div
          key={p.id}
          style={{
            position: "absolute",
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.18)",
            animation: `floatUp ${p.duration}s ${p.delay}s infinite ease-in-out`,
            pointerEvents: "none",
          }}
        />
      ))}

      {/* Background blobs */}
      <div style={{
        position: "absolute", width: 520, height: 520,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(46,204,113,0.25) 0%, transparent 70%)",
        top: "-120px", left: "-120px", pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", width: 400, height: 400,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(168,237,188,0.2) 0%, transparent 70%)",
        bottom: "-80px", right: "-80px", pointerEvents: "none",
      }} />

      {/* Card */}
      <div
        style={{
          background: "rgba(255,255,255,0.14)",
          backdropFilter: "blur(32px)",
          WebkitBackdropFilter: "blur(32px)",
          border: "1.5px solid rgba(255,255,255,0.35)",
          borderRadius: 32,
          padding: "56px 52px",
          maxWidth: 480,
          width: "90%",
          boxShadow: "0 32px 80px rgba(0,0,0,0.28), 0 0 0 1px rgba(255,255,255,0.1) inset",
          opacity: mounted ? 1 : 0,
          transform: mounted ? "translateY(0)" : "translateY(40px)",
          transition: "opacity 0.8s ease, transform 0.8s ease",
          position: "relative",
          zIndex: 10,
        }}
      >
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div style={{
            width: 88, height: 88,
            borderRadius: 28,
            background: "linear-gradient(135deg, #1a7a55, #2ecc71)",
            margin: "0 auto 20px",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 16px 40px rgba(46,204,113,0.45)",
            animation: "pulse 2.5s infinite ease-in-out",
          }}>
            <span style={{ fontSize: 42 }}>♻️</span>
          </div>
          <h1 style={{
            color: "#fff",
            fontSize: 38,
            fontWeight: 900,
            margin: "0 0 6px",
            letterSpacing: "-1px",
            textShadow: "0 2px 12px rgba(0,0,0,0.2)",
          }}>EcoSnap</h1>
          <p style={{
            color: "rgba(255,255,255,0.82)",
            fontSize: 15,
            fontWeight: 400,
            margin: 0,
            letterSpacing: "0.3px",
          }}>AI-Powered Waste Intelligence Platform</p>
        </div>

        {/* Features pills */}
        <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginBottom: 36 }}>
          {["🎯 Instant Detection", "🌍 Eco Impact", "🏆 Earn Points"].map((f) => (
            <span key={f} style={{
              background: "rgba(255,255,255,0.18)",
              border: "1px solid rgba(255,255,255,0.3)",
              color: "#fff",
              borderRadius: 50,
              padding: "5px 14px",
              fontSize: 12,
              fontWeight: 600,
              letterSpacing: "0.2px",
            }}>{f}</span>
          ))}
        </div>

        {/* Input */}
        <div style={{ marginBottom: 12 }}>
          <label style={{
            display: "block",
            color: "rgba(255,255,255,0.9)",
            fontSize: 13,
            fontWeight: 600,
            marginBottom: 10,
            letterSpacing: "0.5px",
            textTransform: "uppercase",
          }}>Your Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => { setName(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            placeholder="e.g. Alex Johnson"
            style={{
              width: "100%",
              padding: "16px 20px",
              borderRadius: 16,
              border: error ? "1.5px solid rgba(255,120,120,0.8)" : "1.5px solid rgba(255,255,255,0.35)",
              background: "rgba(255,255,255,0.15)",
              backdropFilter: "blur(8px)",
              color: "#fff",
              fontSize: 16,
              fontWeight: 500,
              outline: "none",
              boxSizing: "border-box",
              transition: "border-color 0.2s, box-shadow 0.2s",
              fontFamily: "'Inter', sans-serif",
            }}
            onFocus={(e) => { e.target.style.borderColor = "rgba(255,255,255,0.7)"; e.target.style.boxShadow = "0 0 0 3px rgba(255,255,255,0.12)"; }}
            onBlur={(e) => { e.target.style.borderColor = error ? "rgba(255,120,120,0.8)" : "rgba(255,255,255,0.35)"; e.target.style.boxShadow = "none"; }}
          />
          {error && (
            <p style={{ color: "rgba(255,160,160,1)", fontSize: 13, marginTop: 8, marginBottom: 0, fontWeight: 500 }}>
              ⚠️ {error}
            </p>
          )}
        </div>

        {/* CTA Button */}
        <button
          onClick={handleSubmit}
          style={{
            width: "100%",
            padding: "17px",
            borderRadius: 16,
            border: "none",
            background: "linear-gradient(135deg, #0f4c35 0%, #1a7a55 50%, #2ecc71 100%)",
            color: "#fff",
            fontSize: 17,
            fontWeight: 700,
            cursor: "pointer",
            marginTop: 8,
            boxShadow: "0 8px 32px rgba(46,204,113,0.5)",
            transition: "transform 0.15s, box-shadow 0.15s",
            letterSpacing: "0.2px",
            fontFamily: "'Inter', sans-serif",
          }}
          onMouseEnter={(e) => { (e.target as HTMLElement).style.transform = "translateY(-2px)"; (e.target as HTMLElement).style.boxShadow = "0 14px 40px rgba(46,204,113,0.6)"; }}
          onMouseLeave={(e) => { (e.target as HTMLElement).style.transform = "translateY(0)"; (e.target as HTMLElement).style.boxShadow = "0 8px 32px rgba(46,204,113,0.5)"; }}
        >
          🚀 Get Started
        </button>

        <p style={{
          color: "rgba(255,255,255,0.5)",
          fontSize: 12,
          textAlign: "center",
          marginTop: 20,
          marginBottom: 0,
        }}>
          No account needed · 100% free · Privacy first
        </p>
      </div>

      <style>{`
        @keyframes floatUp {
          0%, 100% { transform: translateY(0) scale(1); opacity: 0.5; }
          50% { transform: translateY(-22px) scale(1.1); opacity: 1; }
        }
        @keyframes pulse {
          0%, 100% { box-shadow: 0 16px 40px rgba(46,204,113,0.45); transform: scale(1); }
          50% { box-shadow: 0 20px 56px rgba(46,204,113,0.65); transform: scale(1.04); }
        }
        input::placeholder { color: rgba(255,255,255,0.45); }
      `}</style>
    </div>
  );
}
