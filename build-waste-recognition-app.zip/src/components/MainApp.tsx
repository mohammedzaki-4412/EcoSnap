import { useState, useEffect, useRef } from "react";
import { wasteDatabase, getBadge, WasteInfo } from "../data/wasteData";
import CameraView from "./CameraView";
import ResultCard from "./ResultCard";
import Header from "./Header";
import HistoryPanel from "./HistoryPanel";

interface Props {
  userName: string;
}

export interface ScanResult {
  wasteInfo: WasteInfo;
  confidence: number;
  rawLabel: string;
  timestamp: Date;
}

declare global {
  interface Window {
    tmImage: {
      load: (modelURL: string, metadataURL: string) => Promise<any>;
      createWebcam: (width: number, height: number, flip: boolean) => any;
    };
  }
}

const MODEL_URL = "https://teachablemachine.withgoogle.com/models/To_wNBiq1/";

export default function MainApp({ userName }: Props) {
  const [points, setPoints] = useState<number>(() => {
    return parseInt(localStorage.getItem("ecosnap_points") || "0", 10);
  });
  const [scanCount, setScanCount] = useState<number>(() => {
    return parseInt(localStorage.getItem("ecosnap_scans") || "0", 10);
  });
  const [model, setModel] = useState<any>(null);
  const [modelLoading, setModelLoading] = useState(false);
  const [modelLoaded, setModelLoaded] = useState(false);
  const [modelError, setModelError] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [pointsAnim, setPointsAnim] = useState(false);
  const [scanHistory, setScanHistory] = useState<ScanResult[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("ecosnap_history") || "[]").map((h: any) => ({
        ...h,
        timestamp: new Date(h.timestamp),
      }));
    } catch {
      return [];
    }
  });
  const [showHistory, setShowHistory] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [toast, setToast] = useState({ msg: "", visible: false });

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    localStorage.setItem("ecosnap_points", points.toString());
  }, [points]);

  useEffect(() => {
    localStorage.setItem("ecosnap_scans", scanCount.toString());
  }, [scanCount]);

  useEffect(() => {
    localStorage.setItem("ecosnap_history", JSON.stringify(scanHistory.slice(0, 20)));
  }, [scanHistory]);

  const loadModel = async () => {
    if (model || modelLoading) return;
    setModelLoading(true);
    setModelError(null);
    try {
      const loadedModel = await window.tmImage.load(
        MODEL_URL + "model.json",
        MODEL_URL + "metadata.json"
      );
      setModel(loadedModel);
      setModelLoaded(true);
    } catch (err) {
      console.error("Model load error:", err);
      setModelError("Failed to load AI model. Please check your connection.");
    } finally {
      setModelLoading(false);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
      setResult(null);
      await loadModel();
    } catch (err: any) {
      setModelError("Camera access denied. Please allow camera permission and try again.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
    setResult(null);
    setScanning(false);
  };

  const handleScan = async () => {
    if (!model || !videoRef.current || scanning) return;
    setScanning(true);
    setResult(null);

    // Small delay for UX
    await new Promise((r) => setTimeout(r, 1200));

    try {
      const predictions: Array<{ className: string; probability: number }> =
        await model.predict(videoRef.current);

      const best = predictions.reduce((a, b) =>
        a.probability > b.probability ? a : b
      );

      const wasteInfo = wasteDatabase[best.className] || {
        label: best.className,
        emoji: "🗑️",
        bin: "Unknown Bin",
        binColor: "#888",
        tip: "Please consult local waste guidelines.",
        impact: "Proper disposal matters.",
        theme: {
          primary: "#6b7280",
          secondary: "#9ca3af",
          bg: "rgba(107,114,128,0.08)",
          gradient: "linear-gradient(135deg, #374151, #6b7280, #9ca3af)",
          glow: "rgba(107,114,128,0.4)",
          textAccent: "#d1d5db",
        },
        facts: [],
      };

      const scanResult: ScanResult = {
        wasteInfo,
        confidence: Math.round(best.probability * 100),
        rawLabel: best.className,
        timestamp: new Date(),
      };

      setResult(scanResult);
      const newPoints = points + 10;
      setPoints(newPoints);
      setPointsAnim(true);
      setTimeout(() => setPointsAnim(false), 1200);
      const newScanCount = scanCount + 1;
      setScanCount(newScanCount);
      setScanHistory((prev) => [scanResult, ...prev].slice(0, 20));
      setToast({ msg: `+10 points! You detected ${wasteInfo.label}`, visible: true });
      setTimeout(() => setToast({ msg: "", visible: false }), 3000);
    } catch (err) {
      console.error("Prediction error:", err);
      setModelError("Prediction failed. Please try again.");
    } finally {
      setScanning(false);
    }
  };

  const badge = getBadge(points);
  const nextBadge = badge.next;
  const progressPct = nextBadge
    ? Math.min(100, Math.round((points / nextBadge) * 100))
    : 100;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(160deg, #0f4c35 0%, #1a6644 20%, #f0fdf4 55%, #ffffff 100%)",
        fontFamily: "'Inter', sans-serif",
        opacity: mounted ? 1 : 0,
        transition: "opacity 0.6s ease",
      }}
    >
      <Header
        userName={userName}
        points={points}
        pointsAnim={pointsAnim}
        badge={badge}
        scanCount={scanCount}
        onHistoryToggle={() => setShowHistory((v) => !v)}
        showHistory={showHistory}
        onLogout={() => {
          localStorage.removeItem("ecosnap_user");
          window.location.reload();
        }}
      />

      {/* Toast notification */}
      <div style={{
        position: "fixed",
        bottom: 32,
        left: "50%",
        transform: `translateX(-50%) translateY(${toast.visible ? "0" : "80px"})`,
        background: "linear-gradient(135deg, #0f4c35, #1a7a55)",
        color: "#fff",
        padding: "14px 28px",
        borderRadius: 99,
        fontWeight: 700,
        fontSize: 14,
        boxShadow: "0 8px 32px rgba(15,76,53,0.4)",
        zIndex: 999,
        opacity: toast.visible ? 1 : 0,
        transition: "all 0.4s cubic-bezier(0.34,1.56,0.64,1)",
        whiteSpace: "nowrap",
        pointerEvents: "none",
      }}>
        🎉 {toast.msg}
      </div>

      <main style={{ maxWidth: 880, margin: "0 auto", padding: "24px 16px 48px" }}>
        {/* Badge progress bar */}
        <div style={{
          background: "rgba(255,255,255,0.85)",
          backdropFilter: "blur(16px)",
          borderRadius: 20,
          padding: "16px 24px",
          marginBottom: 24,
          boxShadow: "0 4px 24px rgba(0,0,0,0.07)",
          border: "1px solid rgba(255,255,255,0.8)",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 28 }}>{badge.icon}</span>
              <div>
                <p style={{ margin: 0, fontWeight: 700, fontSize: 15, color: "#1a7a55" }}>{badge.label}</p>
                <p style={{ margin: 0, fontSize: 12, color: "#6b7280" }}>
                  {nextBadge ? `${nextBadge - points} pts to next badge` : "Max badge achieved! 🎉"}
                </p>
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <span style={{ fontSize: 22, fontWeight: 800, color: "#0f4c35" }}>{points}</span>
              <span style={{ fontSize: 12, color: "#6b7280", marginLeft: 4 }}>pts</span>
            </div>
          </div>
          <div style={{ background: "#e5e7eb", borderRadius: 99, height: 8, overflow: "hidden" }}>
            <div style={{
              height: "100%",
              width: `${progressPct}%`,
              background: "linear-gradient(90deg, #16a34a, #4ade80)",
              borderRadius: 99,
              transition: "width 0.8s cubic-bezier(0.34,1.56,0.64,1)",
              boxShadow: "0 0 8px rgba(74,222,128,0.5)",
            }} />
          </div>
        </div>

        {/* Model error banner */}
        {modelError && (
          <div style={{
            background: "rgba(254,226,226,0.95)",
            border: "1px solid rgba(239,68,68,0.3)",
            borderRadius: 16,
            padding: "14px 20px",
            marginBottom: 20,
            color: "#b91c1c",
            fontSize: 14,
            fontWeight: 500,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
            ⚠️ {modelError}
            <button onClick={() => setModelError(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "#b91c1c", fontWeight: 700, fontSize: 18 }}>×</button>
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: result ? "minmax(0,1fr) minmax(0,1fr)" : "1fr", gap: 24, alignItems: "start" }}>
          {/* Camera View */}
          <CameraView
            videoRef={videoRef}
            cameraActive={cameraActive}
            scanning={scanning}
            modelLoading={modelLoading}
            modelLoaded={modelLoaded}
            onStart={startCamera}
            onStop={stopCamera}
            onScan={handleScan}
            resultTheme={result?.wasteInfo.theme}
          />

          {/* Result */}
          {result && (
            <ResultCard result={result} onRescan={() => { setResult(null); }} />
          )}
        </div>

        {/* History Panel */}
        {showHistory && (
          <HistoryPanel history={scanHistory} onClose={() => setShowHistory(false)} />
        )}

        {/* Tips row */}
        {!cameraActive && (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: 16,
            marginTop: 28,
          }}>
            {[
              { icon: "📸", title: "Point & Snap", desc: "Hold camera steady over waste item for best accuracy" },
              { icon: "🤖", title: "AI Detection", desc: "Our model classifies waste into Green, Blue, or Red categories" },
              { icon: "🏆", title: "Earn Rewards", desc: "Earn 10 points per scan. Unlock badges as you climb the ladder" },
            ].map((tip) => (
              <div key={tip.title} style={{
                background: "rgba(255,255,255,0.75)",
                backdropFilter: "blur(12px)",
                borderRadius: 20,
                padding: "22px 18px",
                textAlign: "center",
                border: "1px solid rgba(255,255,255,0.8)",
                boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
                transition: "transform 0.2s",
              }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-4px)")}
                onMouseLeave={(e) => (e.currentTarget.style.transform = "translateY(0)")}
              >
                <div style={{ fontSize: 34, marginBottom: 10 }}>{tip.icon}</div>
                <p style={{ margin: "0 0 6px", fontWeight: 700, fontSize: 14, color: "#1a7a55" }}>{tip.title}</p>
                <p style={{ margin: 0, fontSize: 12, color: "#6b7280", lineHeight: 1.5 }}>{tip.desc}</p>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
