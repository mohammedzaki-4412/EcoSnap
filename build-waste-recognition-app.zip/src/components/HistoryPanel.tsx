import { ScanResult } from "./MainApp";

interface Props {
  history: ScanResult[];
  onClose: () => void;
}

export default function HistoryPanel({ history, onClose }: Props) {
  return (
    <div style={{
      marginTop: 24,
      background: "rgba(255,255,255,0.9)",
      backdropFilter: "blur(20px)",
      borderRadius: 28,
      padding: "24px",
      boxShadow: "0 8px 40px rgba(0,0,0,0.1)",
      border: "1px solid rgba(255,255,255,0.8)",
      animation: "slideDown 0.35s cubic-bezier(0.34,1.56,0.64,1)",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h3 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: "#0f4c35" }}>📋 Scan History</h3>
        <button
          onClick={onClose}
          style={{
            background: "#f3f4f6",
            border: "none",
            borderRadius: 10,
            padding: "6px 12px",
            cursor: "pointer",
            fontWeight: 700,
            color: "#6b7280",
            fontSize: 14,
            fontFamily: "'Inter', sans-serif",
          }}
        >
          ✕ Close
        </button>
      </div>

      {history.length === 0 ? (
        <div style={{ textAlign: "center", padding: "32px", color: "#9ca3af" }}>
          <p style={{ fontSize: 48, marginBottom: 12 }}>🗂️</p>
          <p style={{ margin: 0, fontWeight: 600, fontSize: 15 }}>No scans yet</p>
          <p style={{ margin: "6px 0 0", fontSize: 13 }}>Start scanning waste to see your history</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {history.map((item, i) => (
            <div key={i} style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
              padding: "14px 18px",
              borderRadius: 18,
              background: item.wasteInfo.theme.bg,
              border: `1px solid ${item.wasteInfo.theme.secondary}25`,
              transition: "transform 0.2s",
            }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateX(4px)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.transform = "translateX(0)"; }}
            >
              <span style={{ fontSize: 32, flexShrink: 0 }}>{item.wasteInfo.emoji}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ margin: "0 0 2px", fontWeight: 700, fontSize: 14, color: "#111827" }}>{item.wasteInfo.label}</p>
                <p style={{ margin: 0, fontSize: 12, color: "#6b7280" }}>
                  {item.wasteInfo.bin} · {item.timestamp.toLocaleDateString()} {item.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
              <div style={{
                background: item.wasteInfo.theme.secondary,
                borderRadius: 99,
                padding: "4px 12px",
                color: "#fff",
                fontWeight: 700,
                fontSize: 12,
                flexShrink: 0,
              }}>
                {item.confidence}%
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-16px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
