import { useEffect, useState } from "react";
import OnboardingScreen from "./components/OnboardingScreen";
import MainApp from "./components/MainApp";

export default function App() {
  const [userName, setUserName] = useState<string | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("ecosnap_user");
    if (saved) setUserName(saved);
  }, []);

  const handleGetStarted = (name: string) => {
    localStorage.setItem("ecosnap_user", name);
    setIsTransitioning(true);
    setTimeout(() => {
      setUserName(name);
      setIsTransitioning(false);
    }, 600);
  };

  if (!userName) {
    return <OnboardingScreen onGetStarted={handleGetStarted} isTransitioning={isTransitioning} />;
  }

  return <MainApp userName={userName} />;
}
